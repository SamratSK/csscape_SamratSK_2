const express = require('express')
const app = express()
const port = 5000

const readline = require('node:readline');
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
});

app.listen(port, () => {
    console.log(`Server running on  http://localhost:${port}`)
    rl.question(`Enter pincode: `, pin => {
        fetch(`http://www.postalpincode.in/api/pincode/${pin}`)
            .then((res) => res.json())
            .then((res) => {
                const postOffices = res["PostOffice"];
                const place1 = postOffices[0];
                const place2 = postOffices[1];

                console.log(`Place 1: ${place1["Name"]}, State: ${place1["State"]}`);
                console.log(`Place 2: ${place2["Name"]}, State: ${place2["State"]}`);
            });
        rl.close();
    });
})
