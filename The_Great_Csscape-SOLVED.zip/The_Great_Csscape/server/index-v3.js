const express = require('express')
const cors = require('cors')
const app = express()
app.use(cors())
const port = 5000

app.get('/:pin', function (req, res) {
    fetch(`http://www.postalpincode.in/api/pincode/${req.params.pin}`)
        .then((res1) => res1.json())
        .then((res1) => {
            const postOffices = res1["PostOffice"];
            const place1 = postOffices[0];
            const place2 = postOffices[1];

            res.send({
                place1: {
                    name: place1["Name"],
                    state: place1["State"]
                },
                place2: {
                    name: place2["Name"],
                    state: place2["State"]
                }
            });
        });
});


app.listen(port, () => {
    console.log(`Server running on  http://localhost:${port}`);
})