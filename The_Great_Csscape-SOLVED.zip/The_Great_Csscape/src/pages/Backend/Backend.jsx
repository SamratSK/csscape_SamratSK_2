import React, { useState } from 'react';

const BackendOutputPage = () => {
  const [text, setText] = useState('');
  const [response, setResponse] = useState(undefined);

  const makeRequest = () => {
    if(!text) return;

    fetch(`http://localhost:5000/${text}`)
        .then((res1) => res1.json())
        .then((res1) => {
          setResponse(res1)
        });
  }

  return (
    <div style={{ textAlign: 'center', marginTop: '50px', fontFamily: 'Arial, sans-serif' }}>
      <div className='inp'>
        <input type='text' placeholder='Enter PIN' value={text} onChange={e => setText(e.target.value)}/>
        <button onClick={makeRequest}>Get</button>
      </div>
      {response && (<div>
        <ol>
          <li>{response.place1.name} - {response.place1.state}</li>
          <li>{response.place2.name} - {response.place2.state}</li>
        </ol>
        </div>)}
    </div>
  );
};

export default BackendOutputPage;
